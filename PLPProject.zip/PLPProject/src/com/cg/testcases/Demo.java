package com.cg.testcases;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.pageobjects.AddCart;
import com.cg.pageobjects.CompareProduct;
import com.cg.pageobjects.HomePageObject;
import com.cg.pageobjects.PdfWriter1;
import com.cg.utilites.ExcelReader;
import com.cg.utilites.propRead;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

public class Demo {

	private WebDriver driver;
	private HomePageObject homePageObject;
	private CompareProduct compareProductObject;
	private AddCart addCartObject;
	private PdfWriter1 pdfWriter;

	/**
	 * 
	 * This function will initialize browser and load the url in browser
	 * @throws IOException, DocumentException
	 * 
	 */
	@BeforeClass
	public void browser() throws IOException, DocumentException {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(propRead.getprop("url"));
		homePageObject = new HomePageObject(driver);
		pdfWriter = new PdfWriter1(new Document());
		pdfWriter.pdfHeader();
	}

	/**
	 * 
	 * This function will provide the data to calling test Case
	 * @throws IOException
	 * 
	 */
	@DataProvider
	public Object[][] getperformData() throws IOException {

		String filename = "Details.xlsx";
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String sheetname = "perDetails";
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);

	}
	
	/**
	 * 
	 * This function will passed a data to login page and select a product and compare a 
	 * Product from other product and add a product in cart
	 * @param hashTable
	 * @throws Exception
	 * 
	 */
	@Test(dataProvider = "getperformData")
	public void compareProductTest(Hashtable<String, String> hashTable, Method method) throws Exception {
		
		pdfWriter.testCaseName(method.getName());
		homePageObject.flow(pdfWriter);
		homePageObject.log(hashTable.get("Username"), hashTable.get("Password"), pdfWriter);

		compareProductObject = new CompareProduct(driver);
		compareProductObject.getProduct();
		compareProductObject.firstProduct(pdfWriter);
		compareProductObject.secondProduct(pdfWriter);
		compareProductObject.compareLink(pdfWriter);

		addCartObject = new AddCart(driver);
		Thread.sleep(2000);
		addCartObject.addCartPage(pdfWriter);
		Thread.sleep(2000);
		addCartObject.logout(pdfWriter);
	}
	
	/**
	 * 
	 * This function will close a PDP document
	 * 
	 */
	@AfterClass
	public void closeResource() {
		pdfWriter.closeDocument();
	}
}