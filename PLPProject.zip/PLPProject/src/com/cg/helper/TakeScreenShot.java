package com.cg.helper;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class TakeScreenShot {
	
	/**
	 * 
	 * This function will take screenshot
	 * @param webdriver
	 * @throws Exception
	 * 
	 */
	public static File takeSnapShot(WebDriver webdriver) throws Exception {

		// Convert web driver object to TakeScreenshot

		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);

		// Call getScreenshotAs method to create image file

		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);

		return SrcFile;

	}





}
