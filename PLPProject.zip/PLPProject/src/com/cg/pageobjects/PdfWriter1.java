package com.cg.pageobjects;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfWriter1 {

	private Document document;
	private String result = null;
	private static int countStep = 0;

	/**
	 * 
	 * Default Constructor is used to initialize document
	 * 
	 * @param document
	 * @throws FileNotFoundException,
	 *             DocumentException
	 * 
	 */
	public PdfWriter1(Document document) throws FileNotFoundException, DocumentException {
		super();
		this.document = document;
		PdfWriter.getInstance(document,
				new FileOutputStream(System.getProperty("user.dir") + "/testResult/report.pdf"));
		document.open();
	}

	public void pdfHeader() throws DocumentException {
		Font headingFont = new Font(FontFamily.HELVETICA, 32, Font.BOLD);
		Font SubHeadingFont = new Font(FontFamily.HELVETICA, 18, Font.BOLDITALIC);
		Font normalTextFont = new Font(FontFamily.HELVETICA, 14, Font.ITALIC);
		Paragraph projectHeading = new Paragraph("OpenCart Demo", headingFont);
		projectHeading.setAlignment(Element.ALIGN_CENTER);
		document.add(projectHeading);
		document.add(Chunk.NEWLINE);
		document.add(new Paragraph("Scenario : ", SubHeadingFont));
		document.add(new Paragraph("Login\n" + "Compare Products  and Add to Cart and Remove from Cart\n" + "Logout",
				normalTextFont));
		document.add(Chunk.NEWLINE);
		document.add(new Paragraph("Team Members : ", SubHeadingFont));
		document.add(new Paragraph("Nitish\nDhano T\nRasika Kundar\nJaved Ali Shaikh\nPankaj\nArun\nGautham\nRahul",
				normalTextFont));
		document.newPage();

	}

	/*
	 * 
	 * This function will add text or image in PDP document
	 * 
	 * @param document
	 * 
	 * @throws FileNotFoundException, DocumentException
	 * 
	 */
	public void pdfFile(String actual, String expected, File imagepath)
			throws DocumentException, MalformedURLException, IOException {
		countStep++;
		result = checkTest(expected, actual);

		Image img = Image.getInstance(imagepath.getAbsolutePath());
		float imgw = document.getPageSize().getWidth() - document.leftMargin() * 2;

		 img.scaleAbsolute(500f, 400f);

		document.add(Chunk.NEWLINE);
		PdfPTable table = new PdfPTable(new float[] { 2, 4, 4, 2 });
		table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		// table.setTotalWidth(imgw);

		PdfPCell cellHeadStep = new PdfPCell(new Phrase("Step"));
		cellHeadStep.setPadding(8f);
		PdfPCell cellHeadExp = new PdfPCell(new Phrase("Expected"));
		cellHeadExp.setPadding(8f);
		PdfPCell cellHeadAct = new PdfPCell(new Phrase("Actual"));
		cellHeadAct.setPadding(8f);
		PdfPCell cellHeadResult = new PdfPCell(new Phrase("Result"));
		cellHeadResult.setPadding(8f);

		cellHeadResult.setPadding(8f);
		table.addCell(cellHeadStep);
		table.addCell(cellHeadExp);
		table.addCell(cellHeadAct);
		table.addCell(cellHeadResult);
		table.setHeaderRows(1);

		PdfPCell cellStepValue = new PdfPCell(new Phrase(countStep + ""));
		cellStepValue.setPadding(8f);
		PdfPCell cellStepExp = new PdfPCell(new Phrase(expected));
		cellStepExp.setPadding(8f);
		PdfPCell cellStepAct = new PdfPCell(new Phrase(actual));
		cellStepAct.setPadding(8f);
		PdfPCell cellStepResult = new PdfPCell(new Phrase(result));
		cellStepResult.setPadding(8f);
		table.addCell(cellStepValue);
		table.addCell(cellStepExp);
		table.addCell(cellStepAct);
		table.addCell(cellStepResult);

		table.completeRow();

		PdfPCell[] cells = table.getRow(table.getLastCompletedRowIndex()).getCells();
		switch (result) {
		case "Passed":
			cells[cells.length - 1].setBackgroundColor(BaseColor.GREEN);
			break;
		case "Failed":
			cells[cells.length - 1].setBackgroundColor(BaseColor.RED);
			break;
		}
//		img.scaleToFit(table.getTotalWidth(), 770f);

		img.setBorder(Rectangle.BOX);
		img.setBorderColor(BaseColor.BLACK);
		img.setBorderWidth(1);

		PdfPCell cell = new PdfPCell(img, true);
		cell.setColspan(4);
		cell.setPadding(8f);
		table.addCell(cell);
		table.setWidthPercentage(100);
		document.add(table);
		document.add(Chunk.NEWLINE);
		document.add(img);
		document.newPage();
	}

	/**
	 * 
	 * This function will add heading in PDF document or add First Page for report
	 * 
	 * @param name
	 * @throws DocumentException
	 * 
	 */
	public void testCaseName(String name) throws DocumentException {
		document.add(new Paragraph(name));

	}

	/**
	 * 
	 * This function will check actual and expected result
	 * 
	 * @param exp,
	 *            actu
	 * @throws FileNotFoundException,
	 *             DocumentException
	 * 
	 * @return String
	 * 
	 */
	public String checkTest(String exp, String actu) {

		if (exp.equals(actu)) {
			return "Passed";
		} else {
			return "Failed";
		}
	}

	/**
	 * 
	 * This function will close the document
	 * 
	 * @return void
	 * 
	 */
	public void closeDocument() {
		document.close();
	}

}
