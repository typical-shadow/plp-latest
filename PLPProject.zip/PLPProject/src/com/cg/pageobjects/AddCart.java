package com.cg.pageobjects;

import java.io.File;
import java.io.FileNotFoundException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.cg.helper.TakeScreenShot;
import com.cg.testcases.Demo;

public class AddCart {
	private String actual = null;
	private String expected = null;
	private TakeScreenShot takeScreenShot = new TakeScreenShot();
	private File ss;
	private WebDriver driver;
	private Actions a;

	// Locators of Add to Cart Page
	@FindBy(xpath = "//*[@id=\"product-compare\"]/div[1]/a[2]")
	private WebElement addClick;
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/table/tbody/tr/td[2]/a")
	private WebElement itemName;
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/table/tbody/tr/td[2]/a")
	private WebElement itemName1;
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/table/tbody/tr/td[4]/div/span/button[2]")
	private WebElement removeBtn;
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/a")
	private WebElement myaccount;
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")
	private WebElement logout;
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/table/tbody/tr/td[4]/div/input")
	private WebElement qty;
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/table/tbody/tr/td[6]")
	private WebElement price;
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/table/tbody/tr/td[4]/div/span/button[1]")
	private WebElement refresh;
	@FindBy(xpath = "//*[@id=\"checkout-cart\"]/div[1]")
	private WebElement division;
	private String str, str1;

	/**
	 * 
	 * Default Constructor is used to initialize document and initiate all locator
	 * through PageFactory
	 * 
	 * @param driver
	 * 
	 */
	public AddCart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void addCartPage(PdfWriter1 c) throws Exception {
		
		addClick.click();
		Thread.sleep(2000);
		String quan = qty.getAttribute("value");
		Double qtt = Double.parseDouble(quan);
		qtt++;
		qty.clear();
		qty.sendKeys(qtt + "");
		refresh.click();
//		expected = "Success: You have modified your shopping cart!\r\n" + "�";
		expected = "Success: You have modified your shopping cart!";
		actual = division.getText();
		System.out.println(actual);

		if (actual.contains(expected)) {
			ss = takeScreenShot.takeSnapShot(driver);
			c.pdfFile(actual, expected, ss);
		}

		str = itemName.getText();

		str1 = itemName1.getText();

		if (str.equals(str1)) {
			System.out.println("Within If");
		} else {
			System.out.println("else");
		}

		removeBtn.click();
		Thread.sleep(2000);
		expected = "Shopping Cart";
		actual = driver.getTitle();
		ss = takeScreenShot.takeSnapShot(driver);
		c.pdfFile(actual, expected, ss);

	}

	public void logout(PdfWriter1 c) throws Exception {
		
		myaccount.click();
		a = new Actions(driver);
		a.moveToElement(logout).click().perform();
		expected = "Account Logout";
		actual = driver.getTitle();
		ss = takeScreenShot.takeSnapShot(driver);
		c.pdfFile(actual, expected, ss);

	}

}
