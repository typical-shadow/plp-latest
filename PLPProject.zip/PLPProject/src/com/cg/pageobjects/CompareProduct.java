package com.cg.pageobjects;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Factory;

import com.cg.helper.TakeScreenShot;
import com.itextpdf.text.DocumentException;

public class CompareProduct {
	
	private WebDriver driver;
	private String str, str1;
	private String actual = null;
	private String expected = null;
	private TakeScreenShot takeScreenShot = new TakeScreenShot();
	private File screenshotImage;

	// Locators of Compare Product Page
	@FindBy(xpath = "//*[@id=\"menu\"]/div[2]/ul/li[6]/a")
	private WebElement phoneMenu;
	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div[1]/div/div[2]/div[1]/h4/a")
	private WebElement product1;
	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div[2]/div/div[2]/div[1]/h4/a")
	private WebElement product2;
	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div[1]/div/div[2]/div[2]/button[3]")
	private WebElement compareP1;
	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div[2]/div/div[2]/div[2]/button[3]")
	private WebElement compareP2;
	@FindBy(xpath = "//*[@id=\"compare-total\"]")
	private WebElement compareLink;
	@FindBy(xpath = "//*[@id=\"content\"]/table/tbody[1]/tr[3]/td[2]")
	private WebElement iprice1;
	@FindBy(xpath = "//*[@id=\"content\"]/table/tbody[1]/tr[3]/td[3]")
	private WebElement hprice2;
	@FindBy(xpath = "//*[@id=\"content\"]/table/tbody[2]/tr/td[2]/input")
	private WebElement addcart;
	@FindBy(xpath = "//*[@id=\"content\"]/table/tbody[2]/tr/td[3]/input")
	private WebElement addcart2;
	@FindBy(xpath = "//*[@id=\"product-category\"]/div[1]/a[1]")
	private WebElement compareSuccessMsg1;
	@FindBy(xpath = "//*[@id=\"product-compare\"]/div[1]/a[1]")
	private WebElement addToClick;

	public CompareProduct(WebDriver driver) {

		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void getProduct() {

		phoneMenu.click();
	}

	public void firstProduct(PdfWriter1 p) throws Exception {

		str = product1.getText();
		compareP2.click();
		Thread.sleep(2000);
		expected = "Success: You have added iPhone to your product comparison!";
		actual = "Success: You have added " + compareSuccessMsg1.getText() + " to your product comparison!";
		screenshotImage = takeScreenShot.takeSnapShot(driver);
		p.pdfFile(actual, expected, screenshotImage);

	}

	public void secondProduct(PdfWriter1 p) throws Exception {

		str1 = product2.getText();
		compareP1.click();
		Thread.sleep(2000);
		expected = "Success: You have added HTC Touch HD to your product comparison!";
		actual = "Success: You have added " + compareSuccessMsg1.getText() + " to your product comparison!";
		screenshotImage = takeScreenShot.takeSnapShot(driver);
		p.pdfFile(actual, expected, screenshotImage);

	}

	public void compareLink(PdfWriter1 c) throws Exception {

		compareLink.click();
		Thread.sleep(2000);
		expected = "Product Comparison";
		actual = driver.getTitle();
		screenshotImage = takeScreenShot.takeSnapShot(driver);
		c.pdfFile(actual, expected, screenshotImage);

		String p = iprice1.getText();
		String a1 = p.substring(1, (p.length() - 1));
		double price = Double.parseDouble(a1);
		String p1 = hprice2.getText();
		String a = p1.substring(1, (p1.length() - 1));
		double price1 = Double.parseDouble(a);
		
		if (price > price1) {
			addcart2.click();
			Thread.sleep(2000);
			expected = "Success: You have added HTC Touch HD to your shopping cart!";
			actual = "Success: You have added " + addToClick.getText() + " to your shopping cart!";
			screenshotImage = takeScreenShot.takeSnapShot(driver);
			c.pdfFile(actual, expected, screenshotImage);
		} else {
			addcart.click();
			Thread.sleep(2000);
			expected = "Success: You have added iPhone to your shopping cart!";
			actual = "Success: You have added " + addToClick.getText() + " to your shopping cart!";
			screenshotImage = takeScreenShot.takeSnapShot(driver);
			c.pdfFile(actual, expected, screenshotImage);
		}

	}

}
