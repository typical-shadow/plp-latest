package com.cg.pageobjects;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cg.helper.TakeScreenShot;

public class HomePageObject {
	
	private WebDriver driver;
	private Actions action;
	private String actual = null;
	private String expected = null;
	private TakeScreenShot takeScreenShot = new TakeScreenShot();
	private File screenshotImage;

	// Locators of Home Page
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/a")
	private WebElement myacc;
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")
	private WebElement loginclick;
	@FindBy(id = "input-email")
	private WebElement emailid;
	@FindBy(id = "input-password")
	private WebElement psswd;
	@FindBy(xpath = "//*[@id=\"content\"]/div/div[2]/div/form/input")
	private WebElement button;
	@FindBy(xpath = "//*[@id=\"menu\"]/div[2]/ul/li[6]/a")
	private WebElement link;

	public HomePageObject(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
		
	}

	public void flow(PdfWriter1 p) throws Exception {
		
		expected = "Your Store";
		actual = driver.getTitle();
	
		if (actual.equals(expected)) {
			screenshotImage = takeScreenShot.takeSnapShot(driver);

			myacc.click();
			action = new Actions(driver);
			action.moveToElement(loginclick).click().perform();
			p.pdfFile(actual, expected, screenshotImage);

		}
	}

	public void log(String uname, String pass, PdfWriter1 p) throws Exception {
		
		expected = "Account Login";
		actual = driver.getTitle();
		emailid.sendKeys(uname);
		psswd.sendKeys(pass);
		screenshotImage = takeScreenShot.takeSnapShot(driver);
		p.pdfFile(actual, expected, screenshotImage);

		button.click();
		expected = "My Account";
		actual = driver.getTitle();
		screenshotImage = takeScreenShot.takeSnapShot(driver);
		p.pdfFile(actual, expected, screenshotImage);

		link.click();
		expected = "Phones & PDAs";
		actual = driver.getTitle();
		screenshotImage = takeScreenShot.takeSnapShot(driver);
		p.pdfFile(actual, expected, screenshotImage);
	
	}
}
