package com.cg.utilites;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	/**
	 * 
	 * This function will read a data from excel sheet and return a data to calling
	 * function
	 * 
	 * @param filepath,
	 *            filename, sheetname
	 * @return Object[][]
	 * 
	 */
	public static Object[][] ReadExeclDataToObject(String filepath, String filename, String sheetname)
			throws IOException {
		File file = new File(filepath + "/" + filename);
		FileInputStream i = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(i);
		Sheet sheet = wb.getSheet(sheetname);
		int rowcount = sheet.getLastRowNum();
		Object[][] data = new Object[rowcount][1];
		Row keyrow = sheet.getRow(0);
		Hashtable<String, String> rec = null;
		for (int r = 1; r < rowcount + 1; r++) {
			Row datarow = sheet.getRow(r);
			rec = new Hashtable<String, String>();
			for (int c = 0; c < datarow.getLastCellNum(); c++) {
				String key = keyrow.getCell(c).getStringCellValue();
				String val = datarow.getCell(c).getStringCellValue();
				rec.put(key, val);
			}
			data[r - 1][0] = rec;
		}

		wb.close();
		return data;
		
	}

}
